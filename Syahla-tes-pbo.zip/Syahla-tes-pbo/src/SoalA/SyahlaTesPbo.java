
package SoalA;


public class SyahlaTesPbo {

    
    public static void main(String[] args) {
        
    }
    
}
