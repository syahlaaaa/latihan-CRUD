
package SoalB;
import java.util.Scanner;


public class Plat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Masukkan Nomor Plat : ");
        int NomorPlat = scanner.nextInt();
        
        if (NomorPlat >= 2000 && NomorPlat <= 6999) {
            System.out.println("Sepeda Motor");
        }else {
            System.out.println("Bukan Sepeda Motor");
        }
        
        
        
    }
    
}
