/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SoalC;

/**
 *
 * @author ASUS
 */
public class Main extends Mobil{
    public static void main(String[] args) {
        Mobil[] Mobil  = {
            new Mobil("0001","hr v Honda","Ungu",120),
            new Mobil("0002","br v Honda","Merah",180),
            new Mobil("0003","innova Toyota","Hitam",110),
            new Mobil("0004","brio Honda","Pink",120),
            
            
            
        };
        System.out.println("informasi mengenai mobil : ");
        for (Mobil M : Mobil){
            System.out.println("ID : " + M.getId());
            System.out.println("Nama : " + M.getNama());
            System.out.println("Warna : " + M.getWarna());
            System.out.println("Kecepatan : " + M.getKecepatan() + "km/h\n");
        }
    }
    
}
